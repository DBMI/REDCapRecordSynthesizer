

import redcap_record_synthesizer
