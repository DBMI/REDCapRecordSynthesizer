TODAY=$(date +"%B %d, %Y")
cd C:\\Users\\Kevin.Delaney\\PycharmProjects\\REDCapRecordSynthesizer
.\\venv\\Scripts\\anybadge -l "last commit" -v "$TODAY" --overwrite --file .\\.github\\badges\\last-commit-badge.svg