dbmi\_synthesizer.nickname\_and\_diminutive\_names\_lookup package
==================================================================

Submodules
----------

dbmi\_synthesizer.nickname\_and\_diminutive\_names\_lookup.nicknames\_example module
------------------------------------------------------------------------------------

.. automodule:: dbmi_synthesizer.nickname_and_diminutive_names_lookup.nicknames_example
   :members:
   :undoc-members:
   :show-inheritance:

dbmi\_synthesizer.nickname\_and\_diminutive\_names\_lookup.python\_parser module
--------------------------------------------------------------------------------

.. automodule:: dbmi_synthesizer.nickname_and_diminutive_names_lookup.python_parser
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: dbmi_synthesizer.nickname_and_diminutive_names_lookup
   :members:
   :undoc-members:
   :show-inheritance:
