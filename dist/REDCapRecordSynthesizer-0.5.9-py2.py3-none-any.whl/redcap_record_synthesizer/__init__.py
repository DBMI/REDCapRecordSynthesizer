"""
REDCap Record Synthesizer

Class FakeRecordGenerator, which lets us synthesize
patient records with realistic data.
"""
