"""
REDCap Record Synthesizer

Class FakeRecordGenerator, which lets us synthesize
patient records with realistic data.
"""
import nickname_lookup  # type: ignore[import]  # noqa:F401
