"""
Source code
"""

import redcaprecordsynthesizer  # type: ignore[import]  # noqa: F401
