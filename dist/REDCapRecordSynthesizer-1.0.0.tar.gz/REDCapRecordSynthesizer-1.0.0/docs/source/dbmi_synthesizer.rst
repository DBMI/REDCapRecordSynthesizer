dbmi\_synthesizer package
=========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   dbmi_synthesizer.nickname_and_diminutive_names_lookup

Submodules
----------

dbmi\_synthesizer.fake\_records module
--------------------------------------

.. automodule:: dbmi_synthesizer.fake_records
   :members:
   :undoc-members:
   :show-inheritance:

dbmi\_synthesizer.state\_abbr\_conversion module
------------------------------------------------

.. automodule:: dbmi_synthesizer.state_abbr_conversion
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: dbmi_synthesizer
   :members:
   :undoc-members:
   :show-inheritance:
